// generated from rosidl_generator_c/resource/idl.h.em
// with input from tutorial_interfaces:msg/Num.idl
// generated code does not contain a copyright notice

#ifndef TUTORIAL_INTERFACES__MSG__NUM_H_
#define TUTORIAL_INTERFACES__MSG__NUM_H_

#include "tutorial_interfaces/msg/detail/num__struct.h"
#include "tutorial_interfaces/msg/detail/num__functions.h"
#include "tutorial_interfaces/msg/detail/num__type_support.h"

#endif  // TUTORIAL_INTERFACES__MSG__NUM_H_
