// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef TUTORIAL_INTERFACES__MSG__NUM_HPP_
#define TUTORIAL_INTERFACES__MSG__NUM_HPP_

#include "tutorial_interfaces/msg/detail/num__struct.hpp"
#include "tutorial_interfaces/msg/detail/num__builder.hpp"
#include "tutorial_interfaces/msg/detail/num__traits.hpp"
#include "tutorial_interfaces/msg/detail/num__type_support.hpp"

#endif  // TUTORIAL_INTERFACES__MSG__NUM_HPP_
