// generated from rosidl_generator_c/resource/idl.h.em
// with input from tutorial_interfaces:msg/Sphere.idl
// generated code does not contain a copyright notice

#ifndef TUTORIAL_INTERFACES__MSG__SPHERE_H_
#define TUTORIAL_INTERFACES__MSG__SPHERE_H_

#include "tutorial_interfaces/msg/detail/sphere__struct.h"
#include "tutorial_interfaces/msg/detail/sphere__functions.h"
#include "tutorial_interfaces/msg/detail/sphere__type_support.h"

#endif  // TUTORIAL_INTERFACES__MSG__SPHERE_H_
