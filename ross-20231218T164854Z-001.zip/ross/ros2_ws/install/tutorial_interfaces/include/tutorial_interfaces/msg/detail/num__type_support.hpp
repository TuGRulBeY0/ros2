// generated from rosidl_generator_cpp/resource/idl__type_support.hpp.em
// with input from tutorial_interfaces:msg/Num.idl
// generated code does not contain a copyright notice

#ifndef TUTORIAL_INTERFACES__MSG__DETAIL__NUM__TYPE_SUPPORT_HPP_
#define TUTORIAL_INTERFACES__MSG__DETAIL__NUM__TYPE_SUPPORT_HPP_

#include "rosidl_typesupport_interface/macros.h"

#include "tutorial_interfaces/msg/rosidl_generator_cpp__visibility_control.hpp"

#include "rosidl_typesupport_cpp/message_type_support.hpp"

#ifdef __cplusplus
extern "C"
{
#endif
// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_CPP_PUBLIC_tutorial_interfaces
const rosidl_message_type_support_t *
  ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_cpp,
  tutorial_interfaces,
  msg,
  Num
)();
#ifdef __cplusplus
}
#endif

#endif  // TUTORIAL_INTERFACES__MSG__DETAIL__NUM__TYPE_SUPPORT_HPP_
